दक्ष नगरीचा राजा — Premium Website

1. index.html उघडा.
2. gallery01.jpg ते gallery07.jpg = तुमचे सध्याचे 7 फोटो.
3. PHOTO 08 ते PHOTO 20 साठी पुढचे फोटो gallery08.jpg ते gallery20.jpg या नावाने ठेवा.
4. Music हवे असल्यास music.mp3 ही file याच folder मध्ये ठेवा.
5. Spck Editor/Acode मध्ये index.html उघडा आणि Preview करा.

टीप: सध्या 7 uploaded photos वापरले आहेत; उरलेले 13 slots तयार ठेवले आहेत.
